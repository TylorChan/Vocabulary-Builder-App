import{c as t,j as r,r as e,A as o,a as s}from"./App-D1dFTsxZ.js";t.createRoot(document.getElementById("root")).render(r.jsx(e.StrictMode,{children:r.jsx(o,{children:r.jsx(s,{})})}));
